# Todo
- [ ] Build binaries for Linux when [Swift can build a statically linked executable](https://bugs.swift.org/browse/SR-648).