#!/bin/bash

_LFSPointers() {
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    COMPREPLY=()
    opts="--verbose -v --silent --recursive -r --all -a --json --enable-color --disable-color --newline --json-format --backup-directory -b -h --help"
    if [[ $COMP_CWORD == "1" ]]; then
        COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
        return
    fi
    case $prev in
        --json-format)
            COMPREPLY=( $(compgen -W "formatted compact" -- "$cur") )
            return
        ;;
        --backup-directory|-b)
            COMPREPLY=( $(compgen -d -- "$cur") )
            return
        ;;
    esac
    COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
}


complete -F _LFSPointers LFSPointers
